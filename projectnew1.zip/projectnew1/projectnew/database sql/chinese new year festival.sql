-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- 主機： 127.0.0.1
-- 產生時間： 2023 年 01 月 26 日 09:10
-- 伺服器版本： 10.4.27-MariaDB
-- PHP 版本： 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫： `chinese new year festival`
--

-- --------------------------------------------------------

--
-- 資料表結構 `booking`
--

CREATE TABLE `booking` (
  `booking_id` int(10) NOT NULL,
  `booking_name` varchar(255) NOT NULL,
  `booking_gender` varchar(10) NOT NULL,
  `booking_birthday` date NOT NULL,
  `booking_phnumber` varchar(12) NOT NULL,
  `booking_activity` int(54) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `booking`
--

INSERT INTO `booking` (`booking_id`, `booking_name`, `booking_gender`, `booking_birthday`, `booking_phnumber`, `booking_activity`) VALUES
(12, 'khanglittan', 'male', '2023-01-10', '123456789', 3),
(13, 'xxxxxxx', 'female', '2023-01-16', '123456789', 2),
(14, 'xxxxxxx', 'female', '2023-01-04', '2147483647', 3),
(15, 'cvfbbs', 'male', '2023-01-01', '454364', 1),
(17, 'changziyang', 'male', '2023-01-04', '01110698759', 2),
(18, 'changziyang', 'male', '2023-01-04', '01110698759', 1);

-- --------------------------------------------------------

--
-- 資料表結構 `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `category`
--

INSERT INTO `category` (`category_id`, `category_name`) VALUES
(1, 'Lion dance'),
(2, 'Chinese Calligraphy'),
(3, '24 Festival Drums');

-- --------------------------------------------------------

--
-- 資料表結構 `signup`
--

CREATE TABLE `signup` (
  `signup_id` int(10) NOT NULL,
  `signup_name` varchar(255) NOT NULL,
  `signup_phonenumber` varchar(12) NOT NULL,
  `signup_email` varchar(100) NOT NULL,
  `signup_birthday` date NOT NULL,
  `signup_gender` varchar(10) NOT NULL,
  `signup_password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `signup`
--

INSERT INTO `signup` (`signup_id`, `signup_name`, `signup_phonenumber`, `signup_email`, `signup_birthday`, `signup_gender`, `signup_password`) VALUES
(4, 'zhan yu', '1123456789', 'zhanyu@gmail.com', '2023-01-04', 'male', 'qwer123'),
(5, 'cz', '124578963', 'czcz@gmail.com', '2023-01-24', 'male', 'cz123'),
(6, 'aa', '167846514', 'aa@gmail.com', '2023-02-02', 'male', 'aaa'),
(7, 'changziyang', '1110698759', 'ziyangchang251@gmail.com', '2023-02-01', 'male', '1234'),
(10, 'abaa', '01110698759', 'ziyangchang251@gmail.com', '2023-01-25', 'male', '1234');

--
-- 已傾印資料表的索引
--

--
-- 資料表索引 `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`booking_id`);

--
-- 資料表索引 `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- 資料表索引 `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`signup_id`);

--
-- 在傾印的資料表使用自動遞增(AUTO_INCREMENT)
--

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `booking`
--
ALTER TABLE `booking`
  MODIFY `booking_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `signup`
--
ALTER TABLE `signup`
  MODIFY `signup_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
