<?php
    include_once "../config/dbconnect.php";

    $u_id=$_POST["user_id"];
    $f_name=$_POST["first_name"];
    
    $category_id= $_POST['category'];

    $updateItem = mysqli_query($conn,"UPDATE users SET 
        first_name=$f_name, 
        
        category_id=$category,
        
        WHERE u_id=$user_id");


    if($updateItem)
    {
        echo "true";
    }
    
?>