<?php

	$connect= mysqli_connect("localhost","root","","chinese new year festival");

?>