<div >
  <h2>Activity</h2>
  <table class="table ">
    <thead>
      <tr>
        <th class="text-center">S.N.</th>
        
        <th class="text-center">User Name</th>
        
        <th class="text-center">Phone Number</th>
        <th class="text-center">Activity</th>
        <th class="text-center" colspan="2">Action</th>
      </tr>
    </thead>
    <?php
      include_once "../config/dbconnect.php";
      $sql="SELECT * from booking";
      $result=$connect-> query($sql);
      $count=1;
      if ($result-> num_rows > 0){
        while ($row=$result-> fetch_assoc()) {
    ?>
    <tr>
      <td><?=$count?></td>
      
      <td><?=$row["booking_name"]?>
      <td><?=$row["booking_phnumber"]?>
      <td><?=$row["booking_activity"]?></td> 
      
      <td><button class="btn btn-primary" style="height:40px" onclick="itemEditForm('<?=$row['booking_id']?>')">Edit</button></td>
      <td><button class="btn btn-danger" style="height:40px" onclick="itemDelete('<?=$row['booking_id']?>')">Delete</button></td>
      </tr>
      <?php
            $count=$count+1;
          }
        }
      ?>
  </table>


      
    </div>
  </div>

  
</div>

   