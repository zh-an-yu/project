<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="Home.css"/>
		<style>
			input{
				margin-bottom:10px;
			}
			form{
				width:800px;
				margin-left:auto;
				margin-right:auto;
			}
			#applybutton{
				text-align:right;
			}
		</style>
	</head>
	
	<body>
	<form action="" method="post">
		<div id="page">			
			<form>
				<div style="padding-top:100px;">
					<h1>REGISTER FORM</h1>
				</div>
				
			  <div class="regis">
					<hr>
						<label style="font-size:20px;" for="email"><b>Name : </b></label><br>
						<input type="text" name="username" id="username" required><br>
						
						<label style="font-size:20px;"for="gender"><b>Gender : </b></label>
						<input type="radio" name="gender" id="male" value="male" checked>
						<label style="font-size:20px;"for="male">Male</label><br>
						<input style="margin-left:85px;font-size:20px;"type="radio" name="gender" id="female" value="female">	
						<label style="font-size:20px;" for="female">Female</label><br>
						
						<label style="font-size:20px;" for="dob"><b>Date Of Birth : </b></label>
						<input type="date" id="dob" name="dob"><br>
						
						<label style="font-size:20px;" for="email"><b>Phone Number : </b></label><br>
						<input type="text" placeholder="01xxxxxxxxx" name="phone" id="phone" required><br>
						
						<p style="font-size:20px;" ><b>Please select the activities you want to join in:</b></p>
  						<input type="radio" id="activity1" name="activity" value="1">
  						<label style="font-size:20px;" for="activity1"><b>Activity 1 (Twenty-four festival drum [8.00a.m.-12.00p.m.])</b></label><br>
  						<input type="radio" id="activity2" name="activity" value="2">
  						<label style="font-size:20px;" for="activity2"><b>Activity 2 (Lion dance [1.00p.m.-4.00p.m.])</b></label><br>
  						<input type="radio" id="activity3" name="activity" value="3">
  						<label style="font-size:20px;" for="activity3"><b>Activity 3 (Chinese Calligraphy [5.00p.m.-7.00p.m.])</b></label>

						
						
						
					<hr>
				<div id="applybutton">
				
					<button type="submit" name="submit">Apply</button>
				
				
			  </div>
			</form>
			
			
		</div>
		
	</body>
</html>

<?php
	include("connect.php");
	
	if(isset($_POST["submit"]))
	{
		$username = $_POST["username"];
		$gender = $_POST["gender"];
		$birthday = $_POST["dob"];
		$phNum = $_POST["phone"];
		$acty = $_POST["activity"];

		
		$query = "INSERT INTO booking(booking_name,booking_gender,booking_birthday,booking_phnumber,booking_activity)
		VALUES('$username','$gender','$birthday','$phNum','$acty')";
		$result = mysqli_query($connect,$query);
		
		
	mysqli_close($connect);
	
	?>
	
	<script>
		alert("Booking Done!");
		window.location.href = "index.html";
	</script>
	
	<?php
	}