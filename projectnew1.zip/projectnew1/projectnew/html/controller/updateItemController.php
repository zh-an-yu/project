<?php
    include_once "../config/dbconnect.php";

    if(isset($_POST['booking_name'])){
    $booking_name= $_POST['booking_name'];
}else {
$booking_name="";}
	 if(isset($_POST['booking_id'])){
    $booking_id= $_POST['booking_id'];
} else {
$booking_id="";}
	if(isset($_POST['booking_activity'])){
    $booking_activity= $_POST['booking_activity'];
}else {
$booking_activity="";}

    $updateItem = mysqli_query($connect,"UPDATE booking SET 
        booking_name='$booking_name', 
        
        booking_activity='$booking_activity'
        
        WHERE booking_id = '$booking_id'");


    if($updateItem)
    {
        echo "edit successful";
    }
    
?>