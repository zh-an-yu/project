<?php

    include_once "../config/dbconnect.php";
    
    $booking_id=$_POST['record'];
    $query="DELETE FROM booking WHERE booking_id='$booking_id'";

    $data=mysqli_query($connect,$query);

    if($data){
        echo"User Deleted";
    }
    else{
        echo"Not able to delete";
    }
    
?>