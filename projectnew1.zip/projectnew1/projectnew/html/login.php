<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login in Page</title>
    <link rel="stylesheet" href="loginstyle.css">
	<link rel="stylesheet" href="Home.css"/>
</head>
<body>
	<header>
		<div style="width:100%;" class="headlist">
			<a href="Home page.html">Home</a>
			<a href="xx.html">Activity</a>
			<a href="schedule.html">Schedule</a>
			<a href="apply.html">Apply Form</a>
			<a href="contactus.html">Contact Us</a>
			<a href="about us.html">About Us</a>
			<a href="faq.html">FAQ</a>
			<a href="Log out.php">Log Out</a>
			<a style="text-decoration:underline;font-size:12px;"href="adminlogin.html">Admin</a>
		</div>
	</header>
		
		<div class="happy">
		<center>Happy Chinese New Year</center>
		</div>
        </div> 
        <div class="content">
		<h1>Happy<br><span>Chinese New</span><br>Year</h1>
		<p class="par">May This New Year Be Filled With Happiness,Prosperity,and Many Precious Moments <br>With Your Loved Ones.
					<br><br>Open Your Windows To Allow Good Luck To Come Inside<br>Light Up the Lanterns With New Hopes and Aspirations.</p>

                <div class="form">
				<form action="" method="post">
                    <h2>Login Here</h2>
                    <input type="text" name="signname" placeholder="Enter Your Full-Name">
                    <input type="password" name="signpass" placeholder="Enter Your Password">
                    <button class="btnn" name="submit" type="submit">Login</button>
				</form>

                    <p class="link">Don't have an account<br>
                    <a href="signup.php">Register </a> here</a></p>
                </div>
                    </div>
                </div>
        </div>
    </div>
    <script src="https://unpkg.com/ionicons@5.4.0/dist/ionicons.js"></script>
</body>
</html>

<?php
	
	include("connect.php");
	
	if(isset($_POST["submit"]))
	{
	$username = $_POST["signname"];
	$ps = $_POST["signpass"];
	
	$username = stripcslashes($username);
	$password = stripcslashes($ps);
	$username = mysqli_real_escape_string($connect,$username);
	$ps = mysqli_real_escape_string($connect,$ps);
	
	$query = "SELECT * FROM signup where signup_name = '$username' and signup_password = '$ps'";
	$result = mysqli_query($connect,$query);
	$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
	$count = mysqli_num_rows($result);
	
	if($count == 1){
		$_SESSION["login"] = "OK";
		$_SESSION["username"] = "$username";
	}
	
	if(isset($_SESSION["username"]))
	{
		header("location:userapply.php");
	}
	else
	{
	?>
		<script>
		alert("Login unsuccessfully.");
		window.location.href="login.php";
		</script>
	<?php
	}
	}
mysqli_close($connect);
?>