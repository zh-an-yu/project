<?php

$name = $_POST["contact-name"];
$email = $_POST["contact-email"];
$message = $_POST["contact-message"];

$host = "localhost";
$dbname = "contactus_db";
$username = "root";
$password = "";

$conn = mysqli_connect($host,$username,$password,$dbname);

if(mysqli_connect_errno()){
	die("Connection Error: ".mysqli_connect_errno());
}

$sql = "INSERT INTO contactus (name, email,message)
		VALUES(?, ?, ?)";
		
$stml = mysqli_stmt_init($conn);

if(!mysqli_stmt_prepare($stmt,$sql)){
	die(mysqli_errno($conn));
}

mysqli_stmt_bind_param($stmt,"ssii",
					   $name,
					   $email,
					   $message);
					   
mysqli_stmt_execute($stmt);

?>