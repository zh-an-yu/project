<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
	</head>
	
	<body>
		<form action="" method="post">
		  <div class="container">
			
			<link rel="stylesheet" href="signupstyle.css">
			
			<h1><center>Registration Form</center></h1>
			<p><br>Please fill in this form to create an account</p></br>
			<hr>
			
			<label for="full-name"><b>Full Name</b></label>
			<input type="text" id="signname" name="signname" placeholder="Enter Your Full Name" required>
			
			<label for="phone-number"><b>Phone Number</b></label>
			<input type="text" id="signphone" name="signphone" placeholder="Enter Your Phone Number" required>

			<label for="email"><b>Email</b></label>
			<input type="text" id="signemail" name="signemail" placeholder="Enter Your Email" required>
			
			<label for="birthdaty"><b>Date of Birthday</b></label>
			<br><input type="date" id="signbirth" name="signbirth"></br>
			
			<div class="gender">
			<br>
			<label for="gender"><b>Gender :</b></label>
			<input type="radio" id="signgm" name="signgm" value="male">Male
			<input style="margin-left:10px;" type="radio" id="signgf" name="signgm" value="female">Female
			</br>
			
			<br>
			<label for="password"><b>Password</b></label>
			<input type="password" id="signpass" name="signpass" placeholder="Enter Your Password" required>
			</br>

			<p>By creating an account you agree to our <a href="#"> Terms & Privacy</a>.</p>
			<button type="submit" class="registerbtn" name="submit">Register</button>
			
			<p><center>Already have an account? <a href="login.php">Sign in</a>.</p></center>
		  </div>

		</form>
	</body>
</html>

<?php
	include("connect.php");
	
	if(isset($_POST["submit"]))
	{
		$username = $_POST["signname"];
		$phNum = $_POST["signphone"];
		$email = $_POST["signemail"];
		$birthday = $_POST["signbirth"];
		$gender = $_POST["signgm"];
		$ps = $_POST["signpass"];
		
		$query = "INSERT INTO signup(signup_name,signup_phonenumber,signup_email,signup_birthday,signup_gender,signup_password)
		VALUES('$username','$phNum','$email','$birthday','$gender','$ps')";
		$result = mysqli_query($connect,$query);
		
		
	mysqli_close($connect);
	
	?>
	
	<script>
		alert("Sign Up Done!");
		window.location.href = "login.php";
	</script>
	
	<?php
	}