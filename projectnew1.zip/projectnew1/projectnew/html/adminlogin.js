function validate()
{
	var username=document.getElementById("adminname").value;
	var password=document.getElementById("adminpass").value;
	
	if(username=="zyzyczkl" && password=="happy")
	{
		alert("Login Successfully");
		window.location.href="admin.php";
		return false;
	}
	else
	{
		alert("Login Failed");
	}
	
}